// Pre loader
const loader = document.querySelector(".loader");
window.addEventListener("load", function () {
  this.setTimeout(() => loader.classList.add("active"), 1000);
});

// Navbar
const navbarMenu = document.querySelector(".navbar__menu");
const navbarToggler = document.querySelector(".navbar__toggler");
const navbarMenuLiA = document.querySelectorAll(".navbar__menu > li > a");

navbarToggler.addEventListener("click", function () {
  this.classList.toggle("active");
  navbarMenu.classList.toggle("active");
  navbarMenuLiA.forEach(function (element, index) {
    element.style.transitionDelay = `${index * 100}ms`;
  });
});

let opened = false;
document.addEventListener("click", function (event) {
  if (!event.target.closest(".navbar__menu") && opened) {
    navbarMenu.classList.remove("active");
    navbarToggler.classList.remove("active");
    navbarMenuLiA.forEach(function (element) {
      element.style.transitionDelay = "0ms";
    });
  }

  opened = true;

  if (!navbarMenu.classList.contains("active")) {
    setTimeout(() => (opened = false), 0);
  }
});

// To top icon
let toTop = document.querySelector(".to-top");

window.addEventListener("scroll", function () {
  if (window.scrollY > 200) {
    toTop.classList.add("active");
  } else {
    toTop.classList.remove("active");
  }
});

toTop.addEventListener("click", function () {
  window.scrollTo(0, 0);
});

// Animation
const animate = document.querySelectorAll(".animate");
const animateNow = document.querySelectorAll(".animate.now");

window.addEventListener("scroll", function (event) {
  const triggerBottom = (this.innerHeight / 5) * 4;

  animate.forEach(function (anime) {
    const animateTop = anime.getBoundingClientRect().top;

    if (animateTop < triggerBottom) {
      anime.classList.add("animate__active");
    }
  });
});

window.addEventListener("load", function (event) {
  animateNow.forEach(function (anime) {
    setTimeout(function () {
      anime.classList.add("animate__active");
    }, 1300);
  });
});

// Footer year
document.querySelector("#footer-year").innerText = new Date().getFullYear();
